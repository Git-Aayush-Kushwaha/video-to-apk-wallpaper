package dev.astudio.alpine

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.ComponentActivity



class MainActivity : ComponentActivity() {

//    companion object {
//        private const val ORIGINAL_HASH =
//            ""
//
//    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

//        fun checkIntegrity(context: Context): Boolean {
//            return getVideoSHA256(context) == ORIGINAL_HASH
//        }
//
//
//        if (!checkIntegrity(this)) {
//            showWarning()
//            return
//        }

        findViewById<Button>(R.id.btnVideo).setOnClickListener {
            val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            intent.putExtra(
                WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                ComponentName(this, VideoWallpaperService::class.java)
            )
            startActivity(intent)
        }

        findViewById<Button>(R.id.btnImage).setOnClickListener {
            startActivity(Intent(Intent.ACTION_SET_WALLPAPER))
        }
    }

//    private fun showWarning() {
//        AlertDialog.Builder(this)
//            .setTitle("Integrity Error")
//            .setMessage("App files modified.\nPlease reinstall from Play Store.")
//            .setCancelable(false)
//            .setPositiveButton("Exit") { _, _ ->
//                finishAffinity()
//            }
//            .show()
//    }

    //Encryption of application

//    fun getVideoSHA256(context: Context): String {
//        val inputStream = context.resources.openRawResource(R.raw.wallpaper)
//        val digest = MessageDigest.getInstance("SHA-256")
//        val buffer = ByteArray(8192)
//
//        var bytesRead: Int
//        while (inputStream.read(buffer).also { bytesRead = it } != -1) {
//            digest.update(buffer, 0, bytesRead)
//        }
//        inputStream.close()
//        return digest.digest().joinToString("") { "%02x".format(it) }
//    }
}